# BGP AI

BGP AI is an AI Creative Studio: **IMAGINE • CREATE • TRANSFORM**.

## Current foundation
- Splash screen
- Authentication entry screen
- Home screen foundation
- BGP AI black / white / gold visual system
- Subtle blue AI accent
- Home navigation placeholders

## Run locally
1. Install Node.js LTS.
2. Install Expo CLI through the project workflow (`npx expo`).
3. From this folder run `npm install`.
4. Run `npx expo start`.
5. Open with Expo Go on Android/iOS, or use an emulator.

## Next implementation milestone
Replace the temporary auth buttons with real authentication and add persistent navigation/screens for Templates, AI Lab, Projects, and Me. Then connect Supabase and server-side AI services.
