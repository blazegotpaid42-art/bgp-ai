import React, { useState } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, Text, View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const GOLD = '#F7C948';
const BG = '#05070B';
const CARD = '#0D1119';
const MUTED = '#8B95A7';

function Splash({ onDone }: { onDone: () => void }) {
  return (
    <View style={styles.splash}>
      <View style={styles.logoMark}><Text style={styles.logoMarkText}>B</Text></View>
      <Text style={styles.logo}>BGP <Text style={{ color: GOLD }}>AI</Text></Text>
      <Text style={styles.tagline}>IMAGINE • CREATE • TRANSFORM</Text>
      <Pressable style={styles.primaryButton} onPress={onDone}>
        <Text style={styles.primaryText}>Get Started</Text>
      </Pressable>
    </View>
  );
}

function Auth({ onDone }: { onDone: () => void }) {
  return (
    <View style={styles.auth}>
      <Text style={styles.logo}>BGP <Text style={{ color: GOLD }}>AI</Text></Text>
      <Text style={styles.title}>Welcome to BGP AI</Text>
      <Text style={styles.subtitle}>Your AI creative studio for images, videos and transformations.</Text>
      <Pressable style={styles.primaryButton} onPress={onDone}><Text style={styles.primaryText}>Continue with Google</Text></Pressable>
      <Pressable style={styles.secondaryButton} onPress={onDone}><Text style={styles.secondaryText}>Continue with Apple</Text></Pressable>
      <Pressable onPress={onDone}><Text style={styles.link}>Sign up / Log in with email</Text></Pressable>
      <Text style={styles.terms}>By continuing, you agree to the BGP AI Terms & Conditions and Privacy Policy.</Text>
    </View>
  );
}

const tools = [
  ['sparkles', 'AI Image'], ['videocam', 'AI Video'], ['images', 'Image → Video'],
  ['color-wand', 'AI Edit'], ['flash', 'AI Effects'], ['mic', 'AI Voice']
] as const;

function Home() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View><Text style={styles.logoSmall}>BGP <Text style={{color: GOLD}}>AI</Text></Text><Text style={styles.miniTag}>IMAGINE • CREATE • TRANSFORM</Text></View>
        <Pressable style={styles.upgrade}><Text style={styles.upgradeText}>Upgrade</Text></Pressable>
      </View>
      <View style={styles.hero}>
        <Text style={styles.heroKicker}>BGP AI LAB</Text>
        <Text style={styles.heroTitle}>Turn your ideas into amazing creations.</Text>
        <Text style={styles.heroBody}>Create, edit and transform with AI in one place.</Text>
        <Pressable style={styles.prompt}><Ionicons name="sparkles" size={20} color={GOLD}/><Text style={styles.promptText}>What would you like to create?</Text></Pressable>
      </View>
      <Text style={styles.section}>AI Creation</Text>
      <View style={styles.grid}>{tools.map(([icon, label]) => <View style={styles.tool} key={label}><Ionicons name={icon as any} size={25} color={GOLD}/><Text style={styles.toolText}>{label}</Text></View>)}</View>
      <View style={styles.recent}><Text style={styles.section}>Recent Projects</Text><Text style={styles.muted}>Your creations will appear here.</Text></View>
      <View style={styles.nav}>
        {['home','grid','sparkles','folder','person'].map((icon, i) => <View key={icon} style={styles.navItem}><Ionicons name={icon as any} size={24} color={i===0?GOLD:MUTED}/><Text style={[styles.navText,i===0&&{color:GOLD}]}>{['Home','Templates','AI Lab','Projects','Me'][i]}</Text></View>)}
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  const [stage, setStage] = useState<'splash'|'auth'|'home'>('splash');
  if (stage === 'splash') return <><StatusBar barStyle="light-content"/><Splash onDone={() => setStage('auth')} /></>;
  if (stage === 'auth') return <><StatusBar barStyle="light-content"/><Auth onDone={() => setStage('home')} /></>;
  return <><StatusBar barStyle="light-content"/><Home /></>;
}

const styles = StyleSheet.create({
  splash:{flex:1,backgroundColor:BG,alignItems:'center',justifyContent:'center',padding:28},
  auth:{flex:1,backgroundColor:BG,alignItems:'center',justifyContent:'center',padding:28},
  container:{flex:1,backgroundColor:BG,paddingHorizontal:18},
  logoMark:{width:78,height:78,borderRadius:24,borderWidth:1,borderColor:GOLD,alignItems:'center',justifyContent:'center',marginBottom:18},
  logoMarkText:{fontSize:44,fontWeight:'900',color:GOLD},
  logo:{fontSize:38,fontWeight:'900',color:'#F5F7FA',letterSpacing:1},
  logoSmall:{fontSize:26,fontWeight:'900',color:'#F5F7FA'},
  tagline:{marginTop:10,color:'#C8D0DC',fontSize:12,letterSpacing:2},
  miniTag:{color:MUTED,fontSize:8,letterSpacing:1,marginTop:2},
  title:{fontSize:30,fontWeight:'800',color:'#F5F7FA',marginTop:45,textAlign:'center'},
  subtitle:{color:MUTED,fontSize:15,lineHeight:22,textAlign:'center',marginVertical:14,maxWidth:340},
  primaryButton:{backgroundColor:GOLD,borderRadius:16,paddingVertical:16,paddingHorizontal:28,alignItems:'center',width:'100%',marginTop:20},
  primaryText:{color:'#11151B',fontWeight:'800',fontSize:16},
  secondaryButton:{borderWidth:1,borderColor:'#273143',borderRadius:16,paddingVertical:16,paddingHorizontal:28,alignItems:'center',width:'100%',marginTop:12},
  secondaryText:{color:'#F5F7FA',fontWeight:'700',fontSize:16},
  link:{color:'#7FB7FF',fontWeight:'700',marginTop:22},
  terms:{color:'#667184',fontSize:11,lineHeight:17,textAlign:'center',marginTop:24},
  header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:14},
  upgrade:{borderWidth:1,borderColor:GOLD,borderRadius:20,paddingHorizontal:16,paddingVertical:9},
  upgradeText:{color:GOLD,fontWeight:'800'},
  hero:{backgroundColor:CARD,borderRadius:24,borderWidth:1,borderColor:'#17304B',padding:20,marginTop:8},
  heroKicker:{color:GOLD,fontWeight:'800',fontSize:12,letterSpacing:1},
  heroTitle:{color:'#F5F7FA',fontSize:27,fontWeight:'900',marginTop:8,lineHeight:33},
  heroBody:{color:MUTED,fontSize:14,marginTop:8,lineHeight:20},
  prompt:{marginTop:18,borderWidth:1,borderColor:'#1C74C9',borderRadius:18,padding:14,flexDirection:'row',alignItems:'center',gap:10},
  promptText:{color:'#C9D4E4',fontSize:14},
  section:{color:'#F5F7FA',fontSize:20,fontWeight:'800',marginTop:22,marginBottom:12},
  grid:{flexDirection:'row',flexWrap:'wrap',gap:10},
  tool:{width:'31%',minHeight:100,backgroundColor:CARD,borderRadius:16,borderWidth:1,borderColor:'#1A2535',padding:14,justifyContent:'space-between'},
  toolText:{color:'#E8EDF5',fontSize:12,fontWeight:'700'},
  recent:{flex:1},
  muted:{color:MUTED,fontSize:13},
  nav:{position:'absolute',bottom:0,left:0,right:0,backgroundColor:'#080C13',borderTopWidth:1,borderTopColor:'#1A2433',flexDirection:'row',justifyContent:'space-around',paddingTop:10,paddingBottom:12},
  navItem:{alignItems:'center',gap:3},
  navText:{color:MUTED,fontSize:10,fontWeight:'700'}
});
